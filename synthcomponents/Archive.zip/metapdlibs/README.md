# Pure Pd Objects for Metatone Apps
- also contains a simple effects chain with some of the fx objects which should work with mobmuplat